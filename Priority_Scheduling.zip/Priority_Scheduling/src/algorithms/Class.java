package algorithms;

import java.util.Vector;

public class Class {
	private double importance;
	private String name;
	private Vector<Task> tasks;

	public Class(String n, double i) {
		name = n;
		importance = i;
		tasks = new Vector<Task>();
	}

	public double getImportance() {
		return importance;
	}

	public void setImportance(double importance) {
		this.importance = importance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Vector<Task> getTasks() {
		return tasks;
	}

	public void setTasks(Vector<Task> tasks) {
		this.tasks = tasks;
	}

	public void addTask(Task t) {
		tasks.add(t);
	}

}
