package algorithms;

public class Task implements Comparable<Task> {
	private double percentage;
	private String name;
	private int duration;
	private double weight;
	private String classname;

	public Task(String n, double p, int d, String c) {
		name = n;
		percentage = p;
		duration = d;
		weight = 0;
		classname = c;
	}

	public String getClassname() {
		return classname;
	}

	public void setWeight(double w) {
		weight = w;
	}

	public double getWeight() {
		return weight;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	@Override
	public int compareTo(Task t) {
		double w1 = this.getWeight();
		double w2 = t.getWeight();
		if (w1 > w2)
			return 1;
		else if (w1 == w2)
			return 0;
		else
			return -1;
	}

}
