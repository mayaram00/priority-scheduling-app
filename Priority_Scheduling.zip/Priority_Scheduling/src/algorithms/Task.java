package algorithms;

public class Task implements Comparable<Task> {
	private double percentage;
	private String name;
	private int duration;
	private double weight;
	private String classname;
	private double classimportance;
	private String dayDue;
	private int timeDue;
	private int leftToSchedule;

	public Task(String n, double p, int d, String c, double importance, String dayDue, int timeDue) {
		name = n;
		percentage = p;
		duration = d;
		weight = 0;
		classname = c;
		classimportance = importance;
		this.dayDue = dayDue;
		this.timeDue = timeDue;
		leftToSchedule = duration;
	}

	public boolean dueAfter(String day, int start) {
		return dayDue.equals(day) && timeDue > start;
	}

	public String getClassname() {
		return classname;
	}

	public void setWeight(double w) {
		weight = w;
	}

	public void setLeftToSchedule(int d) {
		leftToSchedule = d;
	}

	public int getLeftToSchedule() {
		return leftToSchedule;
	}

	public double getImportance() {
		return classimportance;
	}

	public double getWeight() {
		return weight;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public boolean taskDone(int num) {
		duration -= num;
		return duration == 0;

	}

	@Override
	public int compareTo(Task t) {
		double w1 = this.getWeight();
		double w2 = t.getWeight();
		if (w1 > w2)
			return 1;
		else if (w1 == w2)
			return 0;
		else
			return -1;
	}

}
