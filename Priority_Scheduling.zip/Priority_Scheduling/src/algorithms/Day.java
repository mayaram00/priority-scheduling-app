package algorithms;

public class Day {

	private Interval[] hours = new Interval[24];
	private boolean[] full = new boolean[24];
	private String name;

	public Day(String name) {
		this.name = name;
		for (int i = 0; i < 24; i++) {
			full[i] = false;
		}
	}

	public String getName() {
		return name;
	}

	/*
	 * Given an interval and a name of a task, adds a blocked off interval in
	 * the calendar for the duration of the task/interval
	 */
	public void addBlockedOffInterval(Interval i, String name) {
		int start = i.getStartTime();
		int end = i.getEndTime();
		boolean userTask = i.isUserTask();
		for (int j = start; j < end; j++) {
			hours[j] = new Interval(start, name, userTask);
			full[j] = true;
		}
	}

	public boolean intervalFull(Interval i) {
		return full[i.getStartTime()];
	}

	/*
	 * Iterates through all of the times in that day and returns the first one
	 * that is empty. Returns -1 if there are no empty ones.
	 */
	public int firstAvailable(Interval i) {
		for (int j = i.getStartTime(); j >= 0; j--) {
			if (!full[j]) {
				return j;
			}
		}

		return -1;
	}

	/*
	 * Gets the first empty interval on that day. Essentially is firstAvailable
	 * but from the front
	 */
	public int firstEmptyInterval() {
		for (int i = 0; i < 24; i++) {
			if (!full[i]) {
				return i;
			}
		}

		return -1;
	}

	public boolean hasEmptyIntervals() {
		for (int i = 0; i < 24; i++) {
			if (!full[i])
				return true;
		}

		return false;
	}

	public void unscheduleAnHour(Interval i) {
		hours[i.getStartTime()] = null;
		full[i.getStartTime()] = false;

	}

	public Interval getFirstScheduledTaskAfter(int start) {
		for (int i = start + 1; i < 24; i++) {
			if (full[i]) {
				if (hours[i].isUserTask()) {
					return hours[i];
				}
			}
		}

		return new Interval(-1, "empty", false);
	}

	public void printDay() {
		System.out.println(name);
		for (int i = 0; i < 24; i++) {
			if (full[i] == true) {
				if (i < 10)
					System.out.println(" " + i + ": " + hours[i].getName());
				else
					System.out.println(i + ": " + hours[i].getName());
			} else {
				if (i < 10)
					System.out.println(" " + i + ": " + "_______");
				else
					System.out.println(i + ": " + "_______");
			}

		}
	}

}
