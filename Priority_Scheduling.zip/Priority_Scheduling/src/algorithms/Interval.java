package algorithms;

public class Interval {
	private int startTime;
	private int endTime;
	private double duration;
	private String name;
	private boolean userTask;
	private String day;
	private boolean frontloaded;

	public Interval(int start, String name, boolean userTask) {
		startTime = start;
		endTime = start + 1;
		duration = 1;
		this.name = name;
		this.userTask = userTask;
		frontloaded = false;
	}

	public Interval(int start, int end, String name, boolean userTask) {
		startTime = start;
		endTime = end;
		duration = end - start;
		this.name = name;
		this.userTask = userTask;
		frontloaded = false;
	}

	public void setFrontloaded(boolean front) {
		frontloaded = front;
	}

	public boolean getFrontloaded() {
		return frontloaded;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getDay() {
		return this.day;
	}

	public String getName() {
		return name;
	}

	public int getStartTime() {
		return startTime;
	}

	public int getEndTime() {
		return endTime;
	}

	public boolean isUserTask() {
		return userTask;
	}

	public void setStartTime(int s) {
		startTime = s;
	}

	public void setEndTime(int e) {
		endTime = e;
	}

}
