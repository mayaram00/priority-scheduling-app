package algorithms;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Vector;

public class WeightScheduling {

	private Map<String, Class> classes;
	private Vector<Task> allTasks;
	private Vector<Task> weightedTasks;
	private Calendar c;

	/*
	 * Initialize a list of classes.
	 */
	public WeightScheduling(Calendar c) {
		classes = new HashMap<String, Class>();
		allTasks = new Vector<Task>();
		weightedTasks = new Vector<Task>();
		this.c = c;
	}

	/*
	 * Adds a new class to the vector of classes given an importance
	 */
	public void addClass(String classname, double importance) {
		Class c = new Class(classname, importance);
		if (!classes.containsKey(classname)) {
			classes.put(classname, c);
		}
	}

	/*
	 * Adds a new class to the vector of classes given an instance of a Class
	 */

	public void addClass(Class c) {
		if (!classes.containsKey(c.getName())) {
			classes.put(c.getName(), c);
		}
	}

	/*
	 * Adds a new task to a specified class with given name, percent, and
	 * duration
	 */
	public void addTask(String name, double percent, int duration, String classname, String dayDue, int timeDue) {
		Class c = classes.get(classname);
		Task t = new Task(name, percent, duration, classname, c.getImportance(), dayDue, timeDue);
		c.addTask(t);
		classes.put(classname, c);
		allTasks.add(t);
	}

	/*
	 * Calculates a weight for each task based on the importance of the class
	 * and the percentage of total grade. Weight = 100 * (((0.6) *
	 * (t.getPercentage() / 100)) + ((0.4) * (classImportance / 10))) Prints a
	 * sorted array of tasks from decreasing to increasing order
	 */

	public void assignWeightsToTasks() {
		for (Class c : classes.values()) {
			Vector<Task> temp = c.getTasks();
			double classImportance = c.getImportance();
			for (int i = 0; i < temp.size(); i++) {
				Task t = temp.get(i);
				double reward = 100 * (((0.6) * (t.getPercentage() / 100)) + ((0.4) * (classImportance / 10)));
				double weight = (reward * reward) / t.getDuration();
				t.setWeight(weight);
				weightedTasks.add(t);

			}

		}
		// sorts low to high
		Comparator<Task> comparator = new TaskComparator();
		weightedTasks.sort(comparator);

	}

	/*
	 * Calculates the weights of each task and adds to the given calendar.
	 * Starts at the second to last available interval. Adds all of the tasks
	 * due after that interval to a priority queue. Schedules an hour of the one
	 * with the lowest weight. Decrements the duration of that task by one
	 * (NOTE: does not change the weight). Moves on to the next interval. Adds
	 * any additional tasks to the queue. Schedules one hour of the task with
	 * the lowest weight. Repeats. Returns 1 on success and 0 on failure.
	 * 
	 * Method dependencies: scheduleTasksOn(day, priorityQueue)
	 */

	public boolean scheduleTasks() {
		assignWeightsToTasks();
		Comparator<Task> comp = new TaskComparator();
		PriorityQueue<Task> pq = new PriorityQueue<Task>(1, comp);

		scheduleTasksOn("Saturday", pq);
		scheduleTasksOn("Friday", pq);
		scheduleTasksOn("Thursday", pq);
		scheduleTasksOn("Wednesday", pq);
		scheduleTasksOn("Tuesday", pq);
		scheduleTasksOn("Monday", pq);
		scheduleTasksOn("Sunday", pq);

		return pq.size() == 0;

	}

	/*
	 * Given a day and the current priority queue of tasks, this method starts
	 * at 24 (midnight) on that day and grabs all of the tasks due after
	 * midnight. It iterates through the entire day and adds all the tasks due
	 * on that day.
	 * 
	 * If it finds a task due after a certain time, it tries to schedule it at
	 * the first available time on that day.
	 * 
	 * If scheduling is successful, the task is added to the calendar (in the
	 * method scheduleAtFirstAvailable(day, interval). It schedules 1 hour at a
	 * time. It decrements the duration of the task and removes it from the
	 * priority queue if the task is now empty.
	 * 
	 * If the scheduling is unsuccessful then the task is not scheduled and
	 * remains in the priority queue.
	 * 
	 * Method dependencies: getTasksDueAfter(day, interval, priorityQueue)
	 * calendarInstance.scheduleAtFirstAvailability(day, interval)
	 * 
	 */
	public void scheduleTasksOn(String day, PriorityQueue<Task> pq) {

		for (int i = 23; i >= 0; i--) {
			getTasksDueAfter(day, i, pq);

			if (!pq.isEmpty()) {
				Task t = pq.peek();
				Interval interval = new Interval(i, t.getName(), true);

				boolean success = c.scheduleAtFirstAvailable(day, interval);
				if (success) {
					pq.remove(t);
					int dur = t.getLeftToSchedule() - 1;
					t.setLeftToSchedule(dur);

					if (dur != 0) {
						pq.add(t);
					}
				}
			}
		}

	}

	/*
	 * Given a day, a start time, and the priority queue, adds all of the tasks
	 * due after that time to the priority queue
	 */

	public void getTasksDueAfter(String day, int start, PriorityQueue<Task> pq) {

		for (int j = 0; j < weightedTasks.size(); j++) {
			if (weightedTasks.get(j).dueAfter(day, start)) {

				if (!pq.contains(weightedTasks.get(j)) && weightedTasks.get(j).getLeftToSchedule() != 0) {
					pq.add(weightedTasks.get(j));
				}

			}
		}
	}

	/*
	 * Prints out tasks in order of weight
	 */
	public void printWeightedTasks() {
		for (int i = 0; i < weightedTasks.size(); i++) {
			System.out.println(weightedTasks.get(i).getClassname() + ": [D: " + weightedTasks.get(i).getDuration()
					+ ", I: " + weightedTasks.get(i).getImportance() + ", P: " + weightedTasks.get(i).getPercentage()
					+ "] " + weightedTasks.get(i).getName() + " - " + weightedTasks.get(i).getWeight());
		}
	}

	/*
	 * Frontloads the scheduled task by calling the calendar.frontload()
	 */

	public void frontloadAllTasks() {
		c.frontload();
	}

	/*
	 * Prints out the calendar
	 */

	public void printCalendar() {
		printWeightedTasks();
		c.printCalendar();
	}

	/*
	 * Given two tasks, compares their weights. Note that weights are
	 * initialized to zero if not set. For use in list.sort
	 */
	class TaskComparator implements Comparator<Task> {
		public int compare(Task t1, Task t2) {
			return Double.compare(t1.getWeight(), t2.getWeight());
		}

	}

}
