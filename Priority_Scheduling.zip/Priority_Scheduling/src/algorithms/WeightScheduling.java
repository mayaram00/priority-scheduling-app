package algorithms;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Vector;

public class WeightScheduling {

	private List<Class> classes;

	/*
	 * Initialize a list of classes (harcoded for now). Calculates a weight for
	 * each task based on the importance of the class and the percentage of
	 * total grade. Weight = (0.6)(% of grade) + (0.4)(importance) Prints a
	 * sorted array of tasks from decreasing to increasing order
	 */
	public WeightScheduling() {
		classes = new ArrayList<Class>();
		initializeClasses();
		Vector<Task> tasks = new Vector<Task>();
		for (int i = 0; i < classes.size(); i++) {
			Vector<Task> temp = classes.get(i).getTasks();
			double classImportance = classes.get(i).getImportance();
			for (int j = 0; j < temp.size(); j++) {
				Task t = temp.get(j);
				double weight = ((0.6) * (t.getPercentage() / 100)) + ((0.4) * (classImportance / 10));
				t.setWeight(weight * weight);
				tasks.add(t);
			}
		}
		Comparator<Task> comparator = new TaskComparator();
		tasks.sort(comparator);
		// vector of tasks, unsorted, with weights filled out.
		for (int i = 0; i < tasks.size(); i++) {
			System.out.println(
					tasks.get(i).getClassname() + ": " + tasks.get(i).getName() + " - " + tasks.get(i).getWeight());
		}
	}

	/*
	 * Hard coded for now. Creates tasks and adds them to the respective class.
	 */
	public void initializeClasses() {
		Class cs201 = new Class("CSCI201", 9.5);
		for (int i = 0; i < 3; i++) {
			String name = "Homework " + (i + 1);
			double percent = 5 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 10, cs201.getName());
			cs201.addTask(t);
		}
		for (int i = 0; i < 2; i++) {
			String name = "Exam " + (i + 1);
			double percent = 20 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 25, cs201.getName());
			cs201.addTask(t);
		}
		Class cs270 = new Class("CSCI270", 7.8);
		for (int i = 0; i < 5; i++) {
			String name = "Homework " + (i + 1);
			double percent = 5 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 5, cs270.getName());
			cs270.addTask(t);
		}
		for (int i = 0; i < 2; i++) {
			String name = "Exam " + (i + 1);
			double percent = 20 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 30, cs270.getName());
			cs270.addTask(t);
		}
		Class math = new Class("MATH225", 5.5);
		for (int i = 0; i < 5; i++) {
			String name = "Homework " + (i + 1);
			double percent = 10 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 2, math.getName());
			math.addTask(t);
		}
		for (int i = 0; i < 3; i++) {
			String name = "Exam " + (i + 1);
			double percent = 15 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 10, math.getName());
			math.addTask(t);
		}
		Class mkt = new Class("BUAD307", 2);
		for (int i = 0; i < 10; i++) {
			String name = "Homework " + (i + 1);
			double percent = 1 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 1, mkt.getName());
			mkt.addTask(t);
		}
		for (int i = 0; i < 1; i++) {
			String name = "Exam " + (i + 1);
			double percent = 40 + (10 + i) * (new Random().nextDouble());
			Task t = new Task(name, percent, 10, mkt.getName());
			mkt.addTask(t);
		}

		classes.add(cs201);
		classes.add(cs270);
		classes.add(mkt);
		classes.add(math);
	}

	/*
	 * Given two tasks, compares their weights. Note that weights are
	 * initialized to zero if not set. For use in list.sort
	 */
	class TaskComparator implements Comparator<Task> {
		public int compare(Task t1, Task t2) {
			return Double.compare(t1.getWeight(), t2.getWeight());
		}

	}

	public static void main(String[] args) {
		WeightScheduling test = new WeightScheduling();

	}

}
