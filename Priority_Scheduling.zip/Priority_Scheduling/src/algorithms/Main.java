package algorithms;

public class Main {

	public static void main(String[] args) {
		Calendar c = new Calendar();
		Interval sleep = new Interval(0, 10, "sleep", false);
		c.addBlockedOffTimes("Sunday", sleep);
		c.addBlockedOffTimes("Monday", sleep);
		c.addBlockedOffTimes("Tuesday", sleep);
		c.addBlockedOffTimes("Wednesday", sleep);
		c.addBlockedOffTimes("Thursday", sleep);
		c.addBlockedOffTimes("Friday", sleep);
		c.addBlockedOffTimes("Saturday", sleep);

		c.addBlockedOffTime("Monday", 10, "work", false);
		c.addBlockedOffTime("Monday", 12, "class", false);
		c.addBlockedOffTime("Monday", 15, "work", false);
		c.addBlockedOffTimes("Tuesday", new Interval(16, 18, "class", false));
		c.addBlockedOffTime("Wednesday", 11, "work", false);
		c.addBlockedOffTimes("Wednesday", new Interval(19, 22, "class", false));
		c.addBlockedOffTime("Thursday", 13, "work", false);
		c.addBlockedOffTimes("Thursday", new Interval(16, 18, "class", false));
		c.addBlockedOffTime("Friday", 10, "bits", false);
		c.addBlockedOffTime("Friday", 12, "bits", false);

		// c.printCalendar();

		WeightScheduling test = new WeightScheduling(c);
		test.addClass("cs201", 8.0);
		test.addClass("cs270", 10.0);
		test.addClass("mkt", 5.0);
		// percent then duration
		test.addTask("homework1", 5.0, 2, "cs201", "Friday", 12);
		test.addTask("more important homework", 5.0, 4, "cs201", "Friday", 11);
		test.addTask("homework2", 5.0, 2, "cs270", "Thursday", 12);
		test.addTask("exam", 20, 2, "mkt", "Wednesday", 12);
		boolean success = test.scheduleTasks();
		System.out.println("scheduled all tasks? " + success);
		// test.printCalendar();
		test.frontloadAllTasks();
		test.printCalendar();
	}

}
