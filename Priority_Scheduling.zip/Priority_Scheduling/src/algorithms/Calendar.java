package algorithms;

import java.util.HashMap;
import java.util.Map;

public class Calendar {
	private Day[] cal = new Day[7];
	private Map<String, Integer> daysOfTheWeek = new HashMap<String, Integer>();

	/*
	 * Initializes a calendar with 7 days of the week. Adds to a map (Day, #)
	 */
	public Calendar() {
		cal[0] = new Day("Sunday");
		daysOfTheWeek.put("Sunday", 0);
		cal[1] = new Day("Monday");
		daysOfTheWeek.put("Monday", 1);
		cal[2] = new Day("Tuesday");
		daysOfTheWeek.put("Tuesday", 2);
		cal[3] = new Day("Wednesday");
		daysOfTheWeek.put("Wednesday", 3);
		cal[4] = new Day("Thursday");
		daysOfTheWeek.put("Thursday", 4);
		cal[5] = new Day("Friday");
		daysOfTheWeek.put("Friday", 5);
		cal[6] = new Day("Saturday");
		daysOfTheWeek.put("Saturday", 6);

	}

	/*
	 * Blocks off a one hour chunk with a given name
	 */
	public void addBlockedOffTime(String day, int startTime, String name, boolean userTask) {
		int index = daysOfTheWeek.get(day);
		Day d = cal[index];
		Interval i = new Interval(startTime, name, userTask);
		i.setDay(day);
		d.addBlockedOffInterval(i, name);
	}

	/*
	 * Blocks off a chunk with a specified interval (can be longer than 1 hr)
	 */
	public void addBlockedOffTimes(String day, Interval interval) {
		interval.setDay(day);
		int index = daysOfTheWeek.get(day);
		Day d = cal[index];
		d.addBlockedOffInterval(interval, interval.getName());

	}

	/*
	 * If the provided interval is full, schedules at the first available time
	 * i.e. if Friday 2 PM is full but Friday 1 PM is free, will schedule Friday
	 * 1PM
	 */

	public boolean scheduleAtFirstAvailable(String day, Interval interval) {
		int index = daysOfTheWeek.get(day);
		Day d = cal[index];
		int startTime = d.firstAvailable(interval);
		if (startTime != -1) {
			interval.setDay(d.getName());
			addBlockedOffTimes(d.getName(), interval);
			return true;
		} else {
			return false;
		}

	}

	/*
	 * If there are empty intervals, tries to move up all of the user-added
	 * tasks to as early as possible
	 */
	public void frontload() {
		// find the first empty interval
		int firstEmptyStartTime = 0;

		Day d = cal[0];
		Interval firstScheduledTask = findFirstScheduledTaskAfter(d.getName(), 0);

		while (d.hasEmptyIntervals() && firstScheduledTask.getStartTime() != -1) {
			firstEmptyStartTime = d.firstEmptyInterval();
			System.out.println("Day: " + d.getName() + " The first empty interval starts at " + firstEmptyStartTime);
			// if a first empty interval exists, find the time of first
			// scheduled task
			if (firstEmptyStartTime != -1) {
				System.out.println(
						"The first scheduled task is " + firstScheduledTask.getName() + " previously scheduled from "
								+ firstScheduledTask.getStartTime() + " to " + firstScheduledTask.getEndTime());
				// if this exists
				if (firstScheduledTask.getStartTime() != -1) {
					String scheduledDayString = firstScheduledTask.getDay();
					int index = daysOfTheWeek.get(scheduledDayString);
					Day scheduledDay = cal[index];
					// remove from the day
					System.out.println(
							"unscheduling " + firstScheduledTask.getName() + " on day " + firstScheduledTask.getDay());
					scheduledDay.unscheduleAnHour(firstScheduledTask);
					cal[index] = scheduledDay;

					// change interval
					firstScheduledTask.setStartTime(firstEmptyStartTime);
					firstScheduledTask.setEndTime(firstEmptyStartTime + 1);
					firstScheduledTask.setFrontloaded(true);

					// move to new time
					System.out.println("adding task " + firstScheduledTask.getName() + " to " + d.getName() + " at "
							+ firstScheduledTask.getStartTime());
					addBlockedOffTimes(d.getName(), firstScheduledTask);

					System.out.println("** finding the first scheduled task after " + d.getName() + " at "
							+ firstScheduledTask.getEndTime());
					firstScheduledTask = findFirstScheduledTaskAfter(d.getName(), firstScheduledTask.getEndTime());
					System.out.println(firstScheduledTask.getName());
				}

			}

		}

	}

	/*
	 * finds first scheduled task
	 */

	public Interval findFirstScheduledTaskAfter(String day, int startTime) {
		int index = daysOfTheWeek.get(day);
		for (int i = index; index < 7; index++) {
			Day d = cal[index];
			Interval first = d.getFirstScheduledTaskAfter(startTime);
			if (first.getStartTime() != -1) {
				if (first.getFrontloaded() == false)
					first.setDay(d.getName());
				return first;
			}
		}

		return new Interval(-1, "blank", false);
	}

	/*
	 * Prints it out day by day
	 */
	public void printCalendar() {
		for (int i = 0; i < 7; i++) {
			cal[i].printDay();

		}
	}

}
